function goChurch() {
    window.location.href = "church.html";
}

function goParty() {
    window.location.href = "party.html";
}
