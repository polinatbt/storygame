function startGame() {
    document.getElementById("main-screen").classList.remove("active");
    document.getElementById("game-screen").classList.add("active");
}
